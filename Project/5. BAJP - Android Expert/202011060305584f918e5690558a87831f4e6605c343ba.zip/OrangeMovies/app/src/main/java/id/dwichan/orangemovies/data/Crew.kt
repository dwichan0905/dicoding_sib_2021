package id.dwichan.orangemovies.data

data class Crew (
    var name: String,
    var job: String
)