package id.dwichan.moviedicts.util.movies

import androidx.recyclerview.widget.DiffUtil
import id.dwichan.moviedicts.data.repository.remote.response.movie.ProductionCompaniesItem

class ProductionCompanyDiffUtilCallback(
    private val oldList: List<ProductionCompaniesItem>,
    private val newList: List<ProductionCompaniesItem>
) : DiffUtil.Callback() {
    override fun getOldListSize(): Int = oldList.size

    override fun getNewListSize(): Int = newList.size

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
        oldItemPosition == newItemPosition

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
        oldItemPosition == newItemPosition
}