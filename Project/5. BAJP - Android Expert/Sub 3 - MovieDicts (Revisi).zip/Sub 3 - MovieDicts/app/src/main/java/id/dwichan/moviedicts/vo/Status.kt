package id.dwichan.moviedicts.vo

enum class Status {
    SUCCESS,
    LOADING,
    ERROR
}