package id.dwichan.moviedicts.core.data.repository.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}