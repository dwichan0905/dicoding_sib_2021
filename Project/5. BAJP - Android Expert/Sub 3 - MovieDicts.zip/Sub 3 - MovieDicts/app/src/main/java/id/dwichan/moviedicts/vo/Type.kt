package id.dwichan.moviedicts.vo

object Type {
    const val MEDIA_TYPE_MOVIES = "movie"
    const val MEDIA_TYPE_TELEVISION = "tv"
    const val INTERVAL_TODAY = "today"
    const val INTERVAL_WEEKLY = "weekly"
}